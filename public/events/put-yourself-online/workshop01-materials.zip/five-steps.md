# 做网站的五步

1. 想清楚：给谁看，放哪三样，想要什么感觉。
2. 生成第一版：挑一个参考网站，填上信息，复制给 AI。
3. 一次改一处：说清哪里不对、想怎么改。改坏了就回上一版。
4. 放上网：建「用户名.github.io」仓库，让 AI 推上去。
5. 以后接着改：回到同一个对话，改完再推一次，网址不变。

推不上去：仓库页 Upload files 传 index.html，再到 Settings → Pages 打开。

# Five steps

1. Decide: Who it's for, three things to show, the feel you want.
2. First version: Pick a site to follow, fill in your details, paste it to an AI.
3. One change at a time: Say what's off and how to fix it. Broke it? Go back a version.
4. Put it online: Make a username.github.io repo and let the AI push to it.
5. Keep it going: Same chat, change it, push again. Same address.

Can't push? Upload index.html on the repo page, then turn on Settings → Pages.
